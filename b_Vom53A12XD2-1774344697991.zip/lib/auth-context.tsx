"use client"

import { createContext, useContext, useState, useEffect, useCallback, type ReactNode } from "react"

export interface User {
  phone: string
  name?: string
  createdAt: string
  isNewUser: boolean
}

interface AuthContextType {
  user: User | null
  isLoading: boolean
  isAuthenticated: boolean
  login: (phone: string, name?: string) => void
  logout: () => void
  updateProfile: (name: string) => void
  checkExistingUser: (phone: string) => boolean
}

const AUTH_STORAGE_KEY = "smart_energy_auth"
const USERS_STORAGE_KEY = "smart_energy_users"

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  // Load user from localStorage on mount
  useEffect(() => {
    const storedAuth = localStorage.getItem(AUTH_STORAGE_KEY)
    if (storedAuth) {
      try {
        const parsedUser = JSON.parse(storedAuth) as User
        setUser(parsedUser)
      } catch {
        localStorage.removeItem(AUTH_STORAGE_KEY)
      }
    }
    setIsLoading(false)
  }, [])

  const checkExistingUser = useCallback((phone: string): boolean => {
    const usersData = localStorage.getItem(USERS_STORAGE_KEY)
    if (!usersData) return false
    
    try {
      const users = JSON.parse(usersData) as Record<string, User>
      return !!users[phone]
    } catch {
      return false
    }
  }, [])

  const login = useCallback((phone: string, name?: string) => {
    const usersData = localStorage.getItem(USERS_STORAGE_KEY)
    let users: Record<string, User> = {}
    
    try {
      users = usersData ? JSON.parse(usersData) : {}
    } catch {
      users = {}
    }

    const existingUser = users[phone]
    
    const userData: User = existingUser 
      ? { ...existingUser, isNewUser: false }
      : {
          phone,
          name: name || undefined,
          createdAt: new Date().toISOString(),
          isNewUser: !name, // If no name provided during first login, mark as new user for profile setup
        }

    // Save to users database
    users[phone] = { ...userData, isNewUser: false } // Store without isNewUser flag
    localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(users))

    // Save current session
    localStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(userData))
    setUser(userData)
  }, [])

  const logout = useCallback(() => {
    localStorage.removeItem(AUTH_STORAGE_KEY)
    setUser(null)
  }, [])

  const updateProfile = useCallback((name: string) => {
    if (!user) return

    const updatedUser: User = { ...user, name, isNewUser: false }
    
    // Update session
    localStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(updatedUser))
    
    // Update users database
    const usersData = localStorage.getItem(USERS_STORAGE_KEY)
    let users: Record<string, User> = {}
    try {
      users = usersData ? JSON.parse(usersData) : {}
    } catch {
      users = {}
    }
    users[user.phone] = updatedUser
    localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(users))
    
    setUser(updatedUser)
  }, [user])

  return (
    <AuthContext.Provider
      value={{
        user,
        isLoading,
        isAuthenticated: !!user,
        login,
        logout,
        updateProfile,
        checkExistingUser,
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}
