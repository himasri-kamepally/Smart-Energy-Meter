"use client"

import { createContext, useContext, useState, useEffect, useCallback, type ReactNode } from "react"

export interface Appliance {
  id: string
  name: string
  room: string
  status: "on" | "off"
  power: number
  icon: string
}

export interface Alert {
  id: string
  type: "warning" | "danger" | "info"
  title: string
  message: string
  timestamp: Date
}

export interface EnergyData {
  totalUsage: number
  todayUsage: number
  monthlyUsage: number
  dailyLimit: number
  billEstimate: number
  connectionStatus: "connected" | "updating" | "offline"
  lastUpdated: Date
  hourlyData: number[]
  dailyData: { day: string; usage: number }[]
  weeklyData: { week: string; usage: number }[]
  monthlyData: { month: string; usage: number }[]
  appliances: Appliance[]
  alerts: Alert[]
  activityLog: { id: string; action: string; timestamp: Date }[]
}

interface EnergyContextType {
  data: EnergyData
  isDarkMode: boolean
  toggleDarkMode: () => void
  isLimitExceeded: boolean
}

const defaultAppliances: Appliance[] = [
  { id: "1", name: "Ceiling Fan", room: "Living Room", status: "on", power: 75, icon: "fan" },
  { id: "2", name: "LED Light", room: "Living Room", status: "on", power: 12, icon: "lightbulb" },
  { id: "3", name: "Air Conditioner", room: "Bedroom", status: "on", power: 1500, icon: "snowflake" },
  { id: "4", name: "Table Lamp", room: "Bedroom", status: "off", power: 25, icon: "lamp" },
  { id: "5", name: "Refrigerator", room: "Kitchen", status: "on", power: 150, icon: "refrigerator" },
  { id: "6", name: "Microwave", room: "Kitchen", status: "off", power: 1000, icon: "microwave" },
  { id: "7", name: "Washing Machine", room: "Utility", status: "off", power: 500, icon: "washing" },
  { id: "8", name: "Water Heater", room: "Bathroom", status: "on", power: 2000, icon: "droplet" },
]

const defaultAlerts: Alert[] = [
  { id: "1", type: "warning", title: "High Usage Detected", message: "Your AC has been running for 8 hours continuously", timestamp: new Date(Date.now() - 3600000) },
  { id: "2", type: "info", title: "Energy Tip", message: "Consider using natural ventilation during cooler hours", timestamp: new Date(Date.now() - 7200000) },
]

const generateHourlyData = () => {
  return Array.from({ length: 24 }, () => Math.random() * 2 + 0.5)
}

const generateDailyData = () => {
  const days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
  return days.map(day => ({ day, usage: Math.random() * 15 + 5 }))
}

const generateWeeklyData = () => {
  return Array.from({ length: 4 }, (_, i) => ({ week: `Week ${i + 1}`, usage: Math.random() * 50 + 30 }))
}

const generateMonthlyData = () => {
  const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun"]
  return months.map(month => ({ month, usage: Math.random() * 200 + 150 }))
}

const EnergyContext = createContext<EnergyContextType | undefined>(undefined)

export function EnergyProvider({ children }: { children: ReactNode }) {
  const [isDarkMode, setIsDarkMode] = useState(true)
  const [data, setData] = useState<EnergyData>({
    totalUsage: 1247.5,
    todayUsage: 4.2,
    monthlyUsage: 187.3,
    dailyLimit: 5,
    billEstimate: 2450,
    connectionStatus: "connected",
    lastUpdated: new Date(),
    hourlyData: generateHourlyData(),
    dailyData: generateDailyData(),
    weeklyData: generateWeeklyData(),
    monthlyData: generateMonthlyData(),
    appliances: defaultAppliances,
    alerts: defaultAlerts,
    activityLog: [
      { id: "1", action: "System connected", timestamp: new Date(Date.now() - 1800000) },
      { id: "2", action: "Data synchronized", timestamp: new Date(Date.now() - 3600000) },
      { id: "3", action: "Daily report generated", timestamp: new Date(Date.now() - 7200000) },
    ],
  })

  const toggleDarkMode = useCallback(() => {
    setIsDarkMode(prev => !prev)
  }, [])

  // Apply dark mode to document
  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add("dark")
    } else {
      document.documentElement.classList.remove("dark")
    }
  }, [isDarkMode])

  // Real-time simulation
  useEffect(() => {
    const interval = setInterval(() => {
      setData(prev => {
        const usageIncrement = Math.random() * 0.05
        const newTodayUsage = Math.min(prev.todayUsage + usageIncrement, 10)
        
        // Randomly toggle appliance status occasionally
        const updatedAppliances = prev.appliances.map(appliance => {
          if (Math.random() < 0.02) {
            return { ...appliance, status: appliance.status === "on" ? "off" : "on" } as Appliance
          }
          return appliance
        })

        // Update hourly data
        const newHourlyData = [...prev.hourlyData.slice(1), Math.random() * 2 + 0.5]

        // Check for limit exceeded and add alert
        const newAlerts = [...prev.alerts]
        if (newTodayUsage > prev.dailyLimit && prev.todayUsage <= prev.dailyLimit) {
          newAlerts.unshift({
            id: Date.now().toString(),
            type: "danger",
            title: "Daily Limit Exceeded",
            message: `Your usage (${newTodayUsage.toFixed(2)} kWh) has exceeded the daily limit of ${prev.dailyLimit} kWh`,
            timestamp: new Date(),
          })
        }

        // Update activity log occasionally
        const newActivityLog = [...prev.activityLog]
        if (Math.random() < 0.1) {
          newActivityLog.unshift({
            id: Date.now().toString(),
            action: "Real-time data updated",
            timestamp: new Date(),
          })
          if (newActivityLog.length > 10) newActivityLog.pop()
        }

        return {
          ...prev,
          todayUsage: newTodayUsage,
          totalUsage: prev.totalUsage + usageIncrement,
          monthlyUsage: prev.monthlyUsage + usageIncrement,
          billEstimate: Math.round((prev.monthlyUsage + usageIncrement) * 13),
          lastUpdated: new Date(),
          hourlyData: newHourlyData,
          appliances: updatedAppliances,
          alerts: newAlerts.slice(0, 10),
          activityLog: newActivityLog,
          connectionStatus: Math.random() < 0.95 ? "connected" : "updating",
        }
      })
    }, 2500)

    return () => clearInterval(interval)
  }, [])

  const isLimitExceeded = data.todayUsage > data.dailyLimit

  return (
    <EnergyContext.Provider value={{ data, isDarkMode, toggleDarkMode, isLimitExceeded }}>
      {children}
    </EnergyContext.Provider>
  )
}

export function useEnergy() {
  const context = useContext(EnergyContext)
  if (context === undefined) {
    throw new Error("useEnergy must be used within an EnergyProvider")
  }
  return context
}
