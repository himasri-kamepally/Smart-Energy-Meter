"use client"

import { useState, useEffect, useRef } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Zap, Phone, Lock, ArrowRight, Loader2, AlertCircle, User, CheckCircle2 } from "lucide-react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/lib/auth-context"
import { cn } from "@/lib/utils"

type Step = "phone" | "otp" | "profile"

export default function LoginPage() {
  const router = useRouter()
  const { login, checkExistingUser, isAuthenticated, isLoading: authLoading } = useAuth()
  
  const [step, setStep] = useState<Step>("phone")
  const [phone, setPhone] = useState("")
  const [otp, setOtp] = useState(["", "", "", "", "", ""])
  const [name, setName] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState("")
  const [isExistingUser, setIsExistingUser] = useState(false)
  
  // Resend OTP timer
  const [resendTimer, setResendTimer] = useState(0)
  const timerRef = useRef<NodeJS.Timeout | null>(null)

  // OTP input refs for better focus management
  const otpRefs = useRef<(HTMLInputElement | null)[]>([])

  // Auto-redirect if already logged in
  useEffect(() => {
    if (!authLoading && isAuthenticated) {
      router.push("/dashboard")
    }
  }, [isAuthenticated, authLoading, router])

  // Handle resend timer countdown
  useEffect(() => {
    if (resendTimer > 0) {
      timerRef.current = setTimeout(() => {
        setResendTimer(prev => prev - 1)
      }, 1000)
    }
    return () => {
      if (timerRef.current) clearTimeout(timerRef.current)
    }
  }, [resendTimer])

  const startResendTimer = () => {
    setResendTimer(30)
  }

  const handleSendOtp = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    
    if (phone.length < 10) {
      setError("Please enter a valid 10-digit phone number")
      return
    }
    
    setIsLoading(true)
    
    // Check if user exists
    const exists = checkExistingUser(phone)
    setIsExistingUser(exists)
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1500))
    
    setIsLoading(false)
    setStep("otp")
    startResendTimer()
    
    // Focus first OTP input
    setTimeout(() => {
      otpRefs.current[0]?.focus()
    }, 100)
  }

  const handleResendOtp = async () => {
    if (resendTimer > 0) return
    
    setError("")
    setIsLoading(true)
    setOtp(["", "", "", "", "", ""])
    
    // Simulate resend API call
    await new Promise(resolve => setTimeout(resolve, 1000))
    
    setIsLoading(false)
    startResendTimer()
    
    // Focus first OTP input
    otpRefs.current[0]?.focus()
  }

  const handleOtpChange = (index: number, value: string) => {
    // Only allow numbers
    if (value && !/^\d$/.test(value)) return
    
    setError("")
    const newOtp = [...otp]
    newOtp[index] = value
    setOtp(newOtp)

    // Auto focus next input
    if (value && index < 5) {
      otpRefs.current[index + 1]?.focus()
    }
  }

  const handleOtpKeyDown = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Backspace") {
      if (!otp[index] && index > 0) {
        otpRefs.current[index - 1]?.focus()
        const newOtp = [...otp]
        newOtp[index - 1] = ""
        setOtp(newOtp)
      }
    } else if (e.key === "ArrowLeft" && index > 0) {
      otpRefs.current[index - 1]?.focus()
    } else if (e.key === "ArrowRight" && index < 5) {
      otpRefs.current[index + 1]?.focus()
    }
  }

  const handleOtpPaste = (e: React.ClipboardEvent) => {
    e.preventDefault()
    const pastedData = e.clipboardData.getData("text").replace(/\D/g, "").slice(0, 6)
    if (pastedData) {
      const newOtp = [...otp]
      pastedData.split("").forEach((char, i) => {
        if (i < 6) newOtp[i] = char
      })
      setOtp(newOtp)
      
      // Focus last filled input or the next empty one
      const lastIndex = Math.min(pastedData.length - 1, 5)
      otpRefs.current[lastIndex]?.focus()
    }
  }

  const handleVerifyOtp = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    
    const otpValue = otp.join("")
    if (otpValue.length < 6) {
      setError("Please enter the complete 6-digit OTP")
      return
    }

    setIsLoading(true)
    
    // Simulate verification - accept any 6 digit OTP except "000000"
    await new Promise(resolve => setTimeout(resolve, 1500))
    
    if (otpValue === "000000") {
      setError("Invalid OTP. Please try again.")
      setIsLoading(false)
      return
    }

    setIsLoading(false)

    if (isExistingUser) {
      // Existing user - login directly
      login(phone)
      router.push("/dashboard")
    } else {
      // New user - show profile setup
      setStep("profile")
    }
  }

  const handleProfileSetup = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")

    if (!name.trim()) {
      setError("Please enter your name")
      return
    }

    setIsLoading(true)
    await new Promise(resolve => setTimeout(resolve, 800))
    
    login(phone, name.trim())
    setIsLoading(false)
    router.push("/dashboard")
  }

  const handleSkipProfile = () => {
    login(phone)
    router.push("/dashboard")
  }

  // Show loading while checking auth state
  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    )
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4 relative overflow-hidden">
      {/* Background image with overlay */}
      <div
        className="absolute inset-0 bg-cover bg-center opacity-10"
        style={{
          backgroundImage: `url(https://images.unsplash.com/photo-1473341304170-971dccb5ac1e?w=1920&q=80)`,
        }}
      />
      <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-secondary/20" />

      <Card className="w-full max-w-md relative z-10 border-border/50 shadow-2xl overflow-hidden">
        {/* Progress indicator */}
        <div className="h-1 bg-muted">
          <div 
            className="h-full bg-primary transition-all duration-500 ease-out"
            style={{ 
              width: step === "phone" ? "33%" : step === "otp" ? "66%" : "100%" 
            }}
          />
        </div>

        <CardHeader className="text-center pb-2">
          <div className="flex justify-center mb-4">
            <div className="flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br from-primary to-secondary">
              <Zap className="w-8 h-8 text-primary-foreground" />
            </div>
          </div>
          <CardTitle className="text-2xl font-bold">Smart Energy Meter</CardTitle>
          <p className="text-muted-foreground mt-2">
            {step === "phone" && "Enter your phone number to continue"}
            {step === "otp" && (
              <>
                Enter the OTP sent to{" "}
                <span className="text-foreground font-medium">+91 {phone}</span>
              </>
            )}
            {step === "profile" && "Welcome! Complete your profile to get started"}
          </p>
          
          {/* User status badge */}
          {step === "otp" && (
            <div className={cn(
              "inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium mt-3 transition-all",
              isExistingUser 
                ? "bg-primary/10 text-primary" 
                : "bg-secondary/10 text-secondary"
            )}>
              {isExistingUser ? (
                <>
                  <CheckCircle2 className="w-3 h-3" />
                  Welcome back!
                </>
              ) : (
                <>
                  <User className="w-3 h-3" />
                  New user
                </>
              )}
            </div>
          )}
        </CardHeader>

        <CardContent className="pt-4">
          {/* Phone Step */}
          <div className={cn(
            "transition-all duration-300",
            step === "phone" ? "opacity-100 translate-x-0" : "hidden"
          )}>
            <form onSubmit={handleSendOtp} className="space-y-6">
              <div className="space-y-2">
                <label className="text-sm font-medium text-foreground">Phone Number</label>
                <div className="relative">
                  <div className="absolute left-3 top-1/2 -translate-y-1/2 flex items-center gap-1 text-muted-foreground">
                    <Phone className="w-4 h-4" />
                    <span className="text-sm font-medium">+91</span>
                  </div>
                  <Input
                    type="tel"
                    placeholder="Enter 10-digit number"
                    value={phone}
                    onChange={e => {
                      setError("")
                      setPhone(e.target.value.replace(/\D/g, "").slice(0, 10))
                    }}
                    className="pl-20 h-12 text-lg tracking-wide"
                    autoFocus
                  />
                </div>
              </div>

              {error && (
                <div className="flex items-center gap-2 text-destructive text-sm animate-in slide-in-from-top-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  {error}
                </div>
              )}

              <Button
                type="submit"
                className="w-full h-12 text-lg gap-2"
                disabled={phone.length < 10 || isLoading}
              >
                {isLoading ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    Sending OTP...
                  </>
                ) : (
                  <>
                    Send OTP
                    <ArrowRight className="w-5 h-5" />
                  </>
                )}
              </Button>
            </form>
          </div>

          {/* OTP Step */}
          <div className={cn(
            "transition-all duration-300",
            step === "otp" ? "opacity-100 translate-x-0" : "hidden"
          )}>
            <form onSubmit={handleVerifyOtp} className="space-y-6">
              <div className="space-y-4">
                <label className="text-sm font-medium text-foreground block text-center">
                  Enter 6-digit OTP
                </label>
                <div className="flex gap-2 justify-center" onPaste={handleOtpPaste}>
                  {otp.map((digit, index) => (
                    <Input
                      key={index}
                      ref={el => { otpRefs.current[index] = el }}
                      type="text"
                      inputMode="numeric"
                      maxLength={1}
                      value={digit}
                      onChange={e => handleOtpChange(index, e.target.value)}
                      onKeyDown={e => handleOtpKeyDown(index, e)}
                      className={cn(
                        "w-12 h-14 text-center text-xl font-bold transition-all",
                        digit && "border-primary bg-primary/5",
                        error && "border-destructive"
                      )}
                    />
                  ))}
                </div>
              </div>

              {error && (
                <div className="flex items-center justify-center gap-2 text-destructive text-sm animate-in slide-in-from-top-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  {error}
                </div>
              )}

              <Button
                type="submit"
                className="w-full h-12 text-lg gap-2"
                disabled={otp.join("").length < 6 || isLoading}
              >
                {isLoading ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    Verifying...
                  </>
                ) : (
                  <>
                    <Lock className="w-5 h-5" />
                    Verify & Continue
                  </>
                )}
              </Button>

              <div className="flex items-center justify-between text-sm">
                <button
                  type="button"
                  onClick={() => {
                    setStep("phone")
                    setOtp(["", "", "", "", "", ""])
                    setError("")
                  }}
                  className="text-muted-foreground hover:text-foreground transition-colors"
                >
                  Change number
                </button>
                
                <button
                  type="button"
                  onClick={handleResendOtp}
                  disabled={resendTimer > 0 || isLoading}
                  className={cn(
                    "transition-colors",
                    resendTimer > 0 
                      ? "text-muted-foreground cursor-not-allowed" 
                      : "text-primary hover:text-primary/80"
                  )}
                >
                  {resendTimer > 0 ? (
                    <span>Resend in {resendTimer}s</span>
                  ) : (
                    "Resend OTP"
                  )}
                </button>
              </div>
            </form>
          </div>

          {/* Profile Setup Step */}
          <div className={cn(
            "transition-all duration-300",
            step === "profile" ? "opacity-100 translate-x-0" : "hidden"
          )}>
            <form onSubmit={handleProfileSetup} className="space-y-6">
              <div className="flex justify-center mb-2">
                <div className="w-20 h-20 rounded-full bg-gradient-to-br from-primary/20 to-secondary/20 flex items-center justify-center">
                  <User className="w-10 h-10 text-primary" />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium text-foreground">Your Name</label>
                <Input
                  type="text"
                  placeholder="Enter your full name"
                  value={name}
                  onChange={e => {
                    setError("")
                    setName(e.target.value)
                  }}
                  className="h-12 text-lg"
                  autoFocus
                />
              </div>

              {error && (
                <div className="flex items-center gap-2 text-destructive text-sm animate-in slide-in-from-top-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  {error}
                </div>
              )}

              <div className="space-y-3">
                <Button
                  type="submit"
                  className="w-full h-12 text-lg gap-2"
                  disabled={isLoading}
                >
                  {isLoading ? (
                    <>
                      <Loader2 className="w-5 h-5 animate-spin" />
                      Setting up...
                    </>
                  ) : (
                    <>
                      <CheckCircle2 className="w-5 h-5" />
                      Complete Setup
                    </>
                  )}
                </Button>

                <Button
                  type="button"
                  variant="ghost"
                  className="w-full h-10 text-muted-foreground"
                  onClick={handleSkipProfile}
                  disabled={isLoading}
                >
                  Skip for now
                </Button>
              </div>
            </form>
          </div>

          {/* Demo hint */}
          <div className="mt-6 p-4 rounded-lg bg-muted/50 border border-border">
            <p className="text-xs text-center text-muted-foreground">
              <span className="font-medium text-foreground">Demo Mode:</span>{" "}
              {step === "phone" && "Enter any 10-digit number"}
              {step === "otp" && "Enter any 6-digit OTP (except 000000)"}
              {step === "profile" && "Enter your name or skip"}
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
